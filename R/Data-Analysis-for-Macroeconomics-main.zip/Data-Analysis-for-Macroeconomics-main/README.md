# Data-Analysis-for-Macroeconomics
The analysis for macroeconomics variables purpose is to analyze the relationship between inflation, FDI, unemployment and GDP nominal for 23 countries in world which represent Asia, Africa, America, Europe and Australia continents. 

# Introduction
The inflation of the countries made some unemployment in the countries and it has the effect to GDP Nominal and made the investors doubt to invest in the countries, Asia and Africa continents is the lucrative market for America, Australia and Europe countries for their economics to invest it. So for Asia and Africa countries it can help reduce the unemployment and reduce the inflation rate in that countries in continents

# Data Analysis
The collection of data used a secondary data which are from worldbank website. The analysis used panel data regression method, originally the data is 30 countries but reduced to 23 countries because when used log some of countries has negative inflation rate so choose to reduce it, I used the diagnostics test for reliability of analysis so can be concluded which are heteroskedasticity and autocorelation test. The tools for analysis used Rstudio.

# Source of Data
Data Source : https://www.worldbank.org/ext/en/home

# Regression result
<img width="545" height="149" alt="Screenshot (1017)" src="https://github.com/user-attachments/assets/10ae404c-628f-4556-993e-d3fdae9c038b" />

# Results 
The results was inflation didn't reduce the GDP Nominal and it very common because when inflation rises the country can reduce it but unemployment and FDI made the GDP nominal per capita reduce or increase, because unemployment made the country not safer and made some people who don't work in long time become criminal and disrupt the economic activities but because majority of the countries want to work the countries must invite the foreign investors which are mostly from western and Australia to invest it. My suggestion is goverments of the countries must open or made the safer environment for investor to invest it and for unemployment must be educated by informal education like course to welcome their first job to the firms that investor set it to the countries, for investor it must be calculate first by set teh firm and government must shorten the bureaucracy to made investor happy so the unemployment can reduce significantly and the investor not burden by another disruptor like givernment policy and etc like gangster or the others. 
